#Hadar Treidel, hadar_t787, 20325554
print("Hello World!")
