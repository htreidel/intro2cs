# hadart_787, Hadar Treidel. 203255542


def convert_spoon_to_cup(spoons_desired):
    cups_needed = spoons_desired / 3.5
    return cups_needed
